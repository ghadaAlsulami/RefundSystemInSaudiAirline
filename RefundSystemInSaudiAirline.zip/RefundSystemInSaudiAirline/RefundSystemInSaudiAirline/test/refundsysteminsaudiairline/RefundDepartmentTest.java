/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package refundsysteminsaudiairline;

import java.io.FileNotFoundException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Groub 27
 */
public class RefundDepartmentTest {

    /**
     * Test of verifyInfo method, of class RefundDepartment.
     */

    @Test
    public void testVerifyInfo() throws Exception {
        System.out.println("verifyInfo");
        String one = "Alghamdi";
        int two = 20000;
        RefundDepartment instance = new RefundDepartment();
        boolean expResult = true;
        boolean result = instance.verifyInfo(one, two);
        assertEquals(expResult, result);
    }


    /**
     * Test of checkPaymentMethod method, of class RefundDepartment.
     */
    @Test
    public void testCheckPaymentMethod() throws Exception {
        System.out.println("checkPaymentMethod");
        String CustomerTicketNum = "20000";
        RefundDepartment instance = new RefundDepartment();
        String expResult = "creditcard";
        String result = instance.checkPaymentMethod(CustomerTicketNum);
        assertEquals(expResult, result);
    }

    /**
     * Test of checkTicketType method, of class RefundDepartment.
     */
    @Test
    public void testCheckTicketType() {
        System.out.println("checkTicketType");
        String TicketNumbr = "20000";
        RefundDepartment instance = new RefundDepartment();
        String expResult = "fees";
        String result = instance.checkTicketType(TicketNumbr);
        assertEquals(expResult, result);

    }
    /**
     * Test of calculateAuto method, of class RefundDepartment.
     */
    @Test
    public void testCalculateAuto() {
        System.out.println("calculateAuto");
        RefundDepartment instance = new RefundDepartment();
        double expResult = 10800.0;

        double result = instance.calculateAuto();
        assertEquals(expResult, result, 0.0);

    }

    /**
     * Test of turnStateIntoR_auto method, of class RefundDepartment.
     */
    @Test
    public void testTurnStateIntoR_auto() {
        System.out.println("turnStateIntoR_auto");
        Boolean r = true;
        RefundDepartment instance = new RefundDepartment();
        String expResult = "R";
        String result = instance.turnStateIntoR_auto(r);
        assertEquals(expResult, result);
    }

    /**
     * Test of turnStateIntoR_manually method, of class RefundDepartment.
     */
    @Test
    public void testTurnStateIntoR_manually() {
        System.out.println("turnStateIntoR_manually");
        String r = "R";
        RefundDepartment instance = new RefundDepartment();
        String expResult = "R";
        String result = instance.turnStateIntoR_manually(r);
        assertEquals(expResult, result);

    }
    /**
     * Test of testSendCreditCardOneByOne method, of class Cash_and_Banking.
     */
    
//      @Test
//    public void testSendCreditCardOneByOne() throws FileNotFoundException {
//        System.out.println("sendCreditCardOneByOne");
//        Cash_Bancking frame_obj = new Cash_Bancking();
//        Cash_and_Banking instance = new Cash_and_Banking();
//        instance.storeCreditCard();
//        String expResult = "20000";
//        frame_obj.setTickNum(expResult);
//
//        String result = instance.sendCreditCardOneByOne(instance.getCreditArray());
//
//        assertEquals(expResult, result);
//    }
     /**
     * Test of testSendFile method, of class Cash_and_Banking.
     */
    
//        @Test
//    public void testSendFile() throws FileNotFoundException {
//        System.out.println("sendFile");
//        Cash_and_Banking instance = new Cash_and_Banking();
//         Cash_Bancking frame_obj = new Cash_Bancking();
//         instance.storeInFile();   
//        String expResult = "2";   
//        frame_obj.setNum(expResult);   
//        String result = instance.sendFile(instance.getCash_array());
//        assertEquals(expResult, result);
//
//    }

}

